from topsis.102017025 import check_input 
from topsis.102017025 import read_data 
from topsis.102017025 import topsis_solve 