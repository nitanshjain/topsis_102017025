from topsis.topsis_102017025 import check_input 
from topsis.topsis_102017025 import read_data 
from topsis.topsis_102017025 import topsis_solve 